import java.util.*;
class Sunny_no{
	public static void main(Strign args[]){
		int n;
		Scanner dc = new Scanner(System.in);
		n = dc.nextInt();
		int r = math.sqrt(n+1);
		if(r-math.floor(r) == 0){
			System.out.println(" yes");
		}
	}
}