import java.util.Date;

public class Test {


	public static void main(String[] args) {
		int i = 10 ;
		int j = 20 ;
		System.out.println("Primitive " + (i == j));
		// non Primitive Java 
//		String  a = new String("abc") ;
//		String b = new String("abc") ;
//		
//		System.out.println("Non Primitive " + (a == b));
//		
//		System.out.println("Non Primitive " + (a.equals(b)));
		
		
//		Account a1 = new Account(101, 4589.0f, "a");
//		Account a2 = new Account(101, 4589.0f, "a");
//		
//		boolean ans = a1.checkEquality(a2);
//		
//		System.out.println(" Non Primitive Account " + ans );
//		
//		System.out.println
//		(" Non Primitive Account " + a1.equals(a2) );		
//		
//		
//Date d = new Date();//
//System.out.println
//(" Non Primitive Account " + a1.equals(d) );	//false 	
//		
//		// a1 == a2	

	}

}







