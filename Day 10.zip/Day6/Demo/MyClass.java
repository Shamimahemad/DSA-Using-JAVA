class MyClass {

	int  i ; // instance variable 
	
	static int count ; // static single 

	public void calcArea()
	{
		float pi  = 3.14f;  // local 
	}

	public void calc(){
		int w = 20;
	}

	p s v main(String[] args)
	{
		MyClass a1 ; // local varaible 

		a1 = new MyClass() ;   // Object Structure runtime

		MyClass a2 = new MyClass();

		s.o.p(a1.i);  // calling of Method 
		
		a1.calcArea(); --- calcArea 


	}// end of main   a1 a2    deallocate 




}